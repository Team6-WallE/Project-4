from django.apps import AppConfig


class BooklookupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'booklookup'
